package testquestion;

import java.util.Scanner;

public class LargestNumber {
	static void number() {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number: ");
		int n=s.nextInt();
		System.out.println("enter the digit that should not be present: ");
		int d=s.nextInt();
		
		int temp=0,temp1=0;
		do {
			int count=0;
			n--;
			temp1=n;
			do {
				temp=temp1%10;
				temp1=(temp1-temp)/10;
				if(temp==d) {
					count--;
				}
			}
			while(temp1!=0); {
				if(count==0) {
					System.out.println(n);
					break;
				}
			}
			
			
		}while(temp1!=0);
		
	}

	
	public static void main(String args[]) {
		number();
	}

}
