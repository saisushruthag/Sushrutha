package assignment;

import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class ConmapCustomer {
	Scanner s=new Scanner(System.in);
	String customer;
	ConmapCustomer obj=new ConmapCustomer();
	 ConcurrentHashMap m = new ConcurrentHashMap(); 
	 
	public void setName(String customer) {
		customer=this.customer;
	}
	public String getName() {
		return customer;
	}
	
	public static void run() {
		System.out.println("executing");
	}
		
	public static void main(String args[]) {
		Thread thread1=new Thread();
		thread1.start();
		run();
		
		
	}

}
