package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Ecommerce  {
	static Scanner s=new Scanner(System.in);
	private static String customername;
	private static String name;
	static void details() {
		
		String name,customeraddress;
		ArrayList customername=new ArrayList();
		System.out.println("enter the customer name: ");
		
		for(int i=1;i<=4;i++) {
			
			name=s.nextLine();
			customername.add(name);
			System.out.println(customername);
		}
		
		ArrayList address=new ArrayList();
		System.out.println("enter the address: ");
		for(int j=1;j<=4;j++) {
			
			customeraddress=s.nextLine();
			customername.add(j);
			System.out.println(customeraddress);
		}
		
		}
	static void loginStatus() {
		String custname;
		System.out.println("enter your name");
		custname=s.nextLine();
		if(custname==name) {
			System.out.println("proceed to login");
		}
			else {
				System.out.println("registrer new");
			}
		}
	
	static void select() {
		int c=s.nextInt();
		switch(c) {
		case 1:
			System.out.println("female");
			break;
		case 2:
			System.out.println("male");
			break;
		case 3:
			System.out.println("child");
			break;
		}
	}
	
		

	public static void main(String args[]) {
		details();
		loginStatus();
		select();
	}

}
